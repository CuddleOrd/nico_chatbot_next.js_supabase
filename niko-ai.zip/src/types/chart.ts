export enum TIMEFRAME {
  DAYS = 'days',
  HOURS = 'hours',
  MINUTES = 'minutes',
}
