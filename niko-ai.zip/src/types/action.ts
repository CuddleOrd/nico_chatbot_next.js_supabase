export interface ActionResponse {
  success: boolean;
  data?: any;
  error?: string;
}
