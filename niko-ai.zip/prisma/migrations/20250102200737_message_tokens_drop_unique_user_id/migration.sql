-- DropIndex
DROP INDEX "token_stats_userId_key";
