-- AlterTable
ALTER TABLE "users" ADD COLUMN     "telegramId" TEXT;
