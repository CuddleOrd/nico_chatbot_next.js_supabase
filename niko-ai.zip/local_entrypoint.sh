#!/bin/bash
pnpm run generate
pnpm run migrate
pnpm run dev